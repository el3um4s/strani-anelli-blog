function test1() {
	this.assert.add(1==1, "1==1");
}

function test2() {
	this.assert.add(1==2, "1==2");
}
